extern const unsigned char g_person_detect_model_data[];
extern const unsigned int g_person_detect_model_data_size;